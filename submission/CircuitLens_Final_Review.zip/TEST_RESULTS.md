# Test Results

Verification for refinement commit `60c827cb794aa446d0080635a9944c9f2797caa9`, rerun on October 3, 2026 while assembling this review package. Application source was not changed.

## Summary

| Check | Result |
| --- | --- |
| Automated test suite | 51 passed; 0 failed, cancelled or skipped |
| Production build | Passed; 57 allowlisted files in dist; secrets and development fixtures excluded |
| Credential-free production smoke | Passed; 49 assets/routes and all seven deterministic demonstrations |
| Smoke perception requests | 0 |
| Dependency audit, including development dependencies | 0 vulnerabilities |
| Secret scan | Passed; working files, reachable Git blobs and distributable assets; environment file ignored and untracked |
| Final refinement browser regression | Passed for exercised controls; clean application console after loading/resize race fix |
| Final refinement responsive review | Desktop 1920/1440, tablet 768, phone 390 CSS pixels; no document overflow |

## Every automated test

Executed with `npm test` (`node --test --test-isolation=none`). These automated/provider-simulated tests do not call OpenAI.

| # | Test | Result |
| --- | --- | --- |
| 1 | HTTP API, validation, security and static assets | PASS |
| 2 | assembly preserves component identity, terminal orientation and engine findings in all seven demos | PASS |
| 3 | review build stays unavailable for pending, unresolved and duplicate accepted parts | PASS |
| 4 | unresolved terminals never create fabricated physical connections or shift editable indices | PASS |
| 5 | continuous camera interpolation stays finite and continuous across story transitions | PASS |
| 6 | cinematic scroll selects stable scenes at boundaries and clamps invalid input | PASS |
| 7 | separate marketing and workspace preserve accessible product entry points | PASS |
| 8 | breadboard strips connect only within each half and row | PASS |
| 9 | jumper union is transitive | PASS |
| 10 | fixture: healthy | PASS |
| 11 | fixture: reversed | PASS |
| 12 | fixture: no-resistor | PASS |
| 13 | fixture: disconnected | PASS |
| 14 | fixture: short | PASS |
| 15 | fixture: divider | PASS |
| 16 | fixture: button | PASS |
| 17 | correct series current and divider output | PASS |
| 18 | comparison tolerates physical relocation | PASS |
| 19 | detect missing components, extra components and value mismatch | PASS |
| 20 | a wire bypassing a resistor creates unsafe LED path | PASS |
| 21 | open button interrupts conduction | PASS |
| 22 | low resistor value flags estimated LED overcurrent | PASS |
| 23 | reject malformed input and duplicate IDs | PASS |
| 24 | all seven diagrams fit narrow and wide canvases without changing topology | PASS |
| 25 | unmeasured canvases and invalid zoom values have safe defaults | PASS |
| 26 | strict schema rejects extra keys, missing fields, malformed boxes and confidence | PASS |
| 27 | unknown holes and resistance are retained as unresolved, never guessed | PASS |
| 28 | low confidence requires explicit review just like all detections | PASS |
| 29 | empty observations cannot create a passing empty circuit | PASS |
| 30 | confirmed perception feeds deterministic engine: healthy | PASS |
| 31 | confirmed perception feeds deterministic engine: reversed | PASS |
| 32 | confirmed perception feeds deterministic engine: disconnected | PASS |
| 33 | human polarity correction clears the same deterministic fault | PASS |
| 34 | rejected detection excluded; unknown accepted detection blocks | PASS |
| 35 | image decoder rejects non-image, SVG, corrupt and oversized input | PASS |
| 36 | valid PNG is normalized without fixture metadata | PASS |
| 37 | API request uses image input and strict schema; no intended design or fault output | PASS |
| 38 | API quota, network and malformed responses fall back without retries or raw errors | PASS |
| 39 | model JSON that violates schema never reaches netlist conversion | PASS |
| 40 | model refusals preserve review fallback | PASS |
| 41 | old UTC ledger resets while same-day cooldown blocks rapid reuse | PASS |
| 42 | daily usage limit persists and counts failures | PASS |
| 43 | serialized requests reject concurrent work; unreadable ledger fails closed | PASS |
| 44 | compact diagrams preserve every editable part and keep symbols within the canvas | PASS |
| 45 | schematic terminal labels agree with engine across all 300 breadboard holes | PASS |
| 46 | schematic retains editable components and only highlights engine findings | PASS |
| 47 | schematic safely escapes imported labels and leaves unresolved terminals unrendered | PASS |
| 48 | vision HTTP integration validates consent, conversion, origins and fallback | PASS |
| 49 | public live requests require deployment access code; manual engine stays open | PASS |
| 50 | color mask highlights saturated pixels without mutating the original | PASS |
| 51 | dark and transparent pixels are not selected | PASS |

## Production smoke outcomes

| Fixture | Result | Findings | Qualified measurement |
| --- | --- | --- | --- |
| healthy | pass | 0 | 9.1 mA, simple series LED approximation |
| reversed | review | 4 | — |
| no-resistor | critical | 3 | — |
| disconnected | review | 2 | — |
| short | critical | 3 | — |
| divider | pass | 0 | 2.50 V, ideal unloaded divider |
| button | pass | 0 | 9.1 mA, simple series LED approximation |

The production smoke checks every served allowlisted asset, content-security headers, credential-free configuration and expected deterministic outcomes. It never invokes live perception.

## Browser evidence from final refinement

- Linked homepage selection, keyboard selection, working correction preview and fault restoration.
- Physical/schematic component synchronization and evidence.
- Desktop and mobile D1 correction clears the reversed-LED fault after confirmation.
- Component add/remove, JSON export fallback, reset, import round-trip and confirmed analysis.
- Local PNG upload and manual-review fallback.
- Explicitly simulated review: consent, reject/reaccept, edits requiring fresh review, unresolved-terminal blocking, accepted netlist conversion and diagnosis.
- Zoom buttons and keyboard zoom/fit; mobile library/inspector coordination.
- System reduced-motion emulation defaults to the schematic and removes selection transitions.
- Final responsive captures visually inspected; fresh-tab console check contains no application errors.

## Testing boundaries

Live vision extraction, recognition accuracy, real electrical continuity and hardware safety are not validated. Real-device pinch/pan and camera capture were not exercised because responsive checks used desktop browser emulation and synthetic touch dispatch was unavailable. Dedicated screen-reader and GPU benchmark testing were not performed. Automatic download persistence was not separately confirmed; the JSON fallback/import round-trip passed.
