# Design Notes

## Selected direction

The refinement continues the existing CircuitLens implementation and preserves its diagnostic engine, demos, previous assets and Git history. Three actual desktop/mobile homepage prototypes informed the selection:

| Direction | Assessment |
| --- | --- |
| Linked physical assembly and schematic | Selected: immediately explains the product through an inspectable circuit and synchronized views |
| Dark fault case study | Strong atmosphere, but less immediate schematic/product clarity |
| Application screenshot hero | Clear software identity, but screenshot text became too small on phones |

The final homepage uses the actual fixture and engineering API, so selection and polarity correction demonstrate working behavior rather than decorative animation.

## Visual decisions

Locally hosted Archivo provides precise interface typography; Georgia italic introduces editorial contrast in marketing headings. An ink-blue and pale-ice palette supports hierarchy, while warmer board materials connect the product to physical electronics. Blue selection marks are distinct from restrained rust fault indicators.

The homepage pairs a generated physical circuit with terminal topology and an evidence readout, followed by a concise explanation, seven examples and a direct product entry. Generated geometry is explicitly distinguished from reconstructed photo geometry and validated live AI results.

Marketing and engineering remain separate pages. The workbench uses a compact toolbar, restrained left example library, large fitted canvas and contextual right inspector. Professional application hierarchy replaces oversized marketing headings and repeated instructional rows. Physical/schematic/source switching relates representations of the same editable circuit.

The schematic uses clearer symbols, stronger strokes, readable labels and larger selection targets. A fitted physical assembly makes the circuit the visual centerpiece. Zoom, fit and keyboard shortcuts support closer inspection without changing electrical topology.

## Responsive and motion decisions

Tablet hides the library by default and retains contextual evidence. Compact tablet homepage topology avoids tiny schematic text.

Mobile starts with a readable schematic, accessible zoom controls and a contextual inspector sheet. The sheet scrolls independently while the entire fitted circuit remains visible above it. Opening the example library closes the sheet. Existing dialogs retain advanced editing, observation review and export functionality.

Motion communicates selection and orientation; reduced motion defaults to the schematic and removes selection transitions. Board resize transitions were removed to avoid misleading transitional frames and unstable capture framing.

## Review and corrections

Final review covered 1920, 1440, 768 and 390 CSS-pixel widths. Corrections included inherited mobile layout rules that shrank the circuit, inspector height, tablet diagram readability and board framing. Browser console inspection also found and fixed a render race during the homepage's initial analysis request.

The included images are the final refinement captures. The interactive demonstration screenshot shows a selected generated physical component and its real deterministic evidence; it does not claim live visual recognition.
