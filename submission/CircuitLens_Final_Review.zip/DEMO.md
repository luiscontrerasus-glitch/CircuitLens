# CircuitLens Demo Guide

## Open the application

For the existing local session, open http://127.0.0.1:3005/ and choose **Open workbench**, or visit http://127.0.0.1:3005/workbench.html directly.

This ZIP contains review materials only. With a separate repository checkout and Node 22.8 or newer, run `npm ci` and `npm start`; the development default is http://127.0.0.1:3000/. Manual analysis works without API credentials. For an existing production build, `node dist/server.js` starts the server using its configured port.

## Interactive homepage

1. Select a component in either the physical assembly or schematic. The same part is selected in both.
2. Read the corresponding evidence below the circuit.
3. Choose **Preview polarity correction**. D1 terminals change and the engineering API confirms supported checks passed.
4. Choose **Restore fault** to restore reversed polarity.
5. Choose **Inspect in workbench** to open the corresponding generated example.

## Workbench basics

Open **Examples** if the library is collapsed. Selecting an example runs its deterministic checks. Switch **Physical**, **Schematic** and **Source image** to inspect the same editable model. Select a component or fault indicator to open contextual evidence.

Use zoom buttons or focus the circuit canvas and press `+`, `-` and `0` (fit). On mobile, selecting a component opens the inspector sheet; scroll inside the sheet to reach editing and confirmation controls. Close the sheet to restore the full canvas.

Edits invalidate previous findings. Check **I checked the component types, terminals and values**, then choose **Analyze connections** to evaluate the corrected model. **All connections & settings** opens the full editor.

## All seven demonstrations

Each starts from a known, explicitly generated fixture. Multiple findings may describe the same physical fault. Reload the example to reset any edits.

| Example library label | Route query | Expected initial result | What to inspect or change |
| --- | --- | --- | --- |
| Healthy LED | `?demo=healthy` | Pass, 0 findings; simple LED estimate 9.1 mA | Inspect R1 = 330 Ω and D1 anode D12/cathode D18. Change resistor value and confirm/analyze to see updated evidence. |
| Reversed polarity | `?demo=reversed` | Review, 4 findings | Select D1, use **Swap A / K**, confirm and analyze. D12/D18 clears the fault and supported checks pass. |
| Open connection | `?demo=disconnected` | Review, 2 findings | W2 starts at A19. Change its A terminal to A18, confirm and analyze to restore the path. |
| Missing resistor | `?demo=no-resistor` | Critical, 3 findings | A jumper W3 replaces the limiter. In the full editor remove W3 and add R1 as a 330 Ω resistor from B5 to B12; confirm and analyze. |
| Crossed rails | `?demo=short` | Critical, 3 findings | W3 bridges VCC and GND. Remove W3, confirm and analyze. |
| Voltage divider | `?demo=divider` | Pass, 0 findings; ideal unloaded output 2.50 V | Inspect both 1 kΩ resistors. Change a resistor value to inspect changed estimates/reference differences. This is an unloaded approximation. |
| Push-button LED | `?demo=button` | Pass, 0 findings; simple LED estimate 9.1 mA | In the full editor set S1 from closed to open; confirm and analyze to observe the interrupted path. Restore closed and re-analyze. |

Append the query to `/workbench.html`. The source illustration remains the original fixture image while editing changes the netlist.

## Export, import and reset

Choose **Export** for the netlist or use the full report to export a report. If automatic saving is unavailable, copy the on-screen JSON into a JSON file. **New** resets the workspace. **All connections & settings → Import JSON** restores an exported netlist. Review, confirm and analyze it again. Netlist exports do not retain uploaded photos.

## Image-review workflow

Choose **Upload circuit**, then upload a JPEG, PNG or WebP. Manual connection entry remains available when API access is missing.

Optional perception requires configured server-side API access, usable credits and explicit image-sharing consent. Review every proposed component and both terminals, accept/reject/edit detections, resolve unknown values and keep IDs unique before building a circuit. Then confirm and run deterministic checks.

Synthetic teaching images and simulated test responses are clearly labeled. The final refinement tested provider-simulated review, not successful live recognition. Do not interpret the generated assembly or supported-rule pass as proof that real hardware is safe or correctly connected.

## Verification to reproduce from a repository checkout

```sh
npm test
npm run check
npm run format:check
npm run build
npm audit
npm run security:check
```

Against an already-running credential-free production server, run `node scripts/smoke-production.js http://127.0.0.1:3005`. This checks assets/routes and all seven deterministic demos without invoking perception.
